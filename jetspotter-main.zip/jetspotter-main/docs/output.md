# Output

The fields below are shown for every medium. Depending on the medium the information can be displayed in a different manner.

```go
{%
   include-markdown "snippets/output.snippet"
   comments=false
%}
```
